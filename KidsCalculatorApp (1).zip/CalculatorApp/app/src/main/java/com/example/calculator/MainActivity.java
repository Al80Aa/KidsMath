package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.animation.BounceInterpolator;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    private TextView displayText, expressionText, starsText;
    private LinearLayout rootLayout;
    private ImageButton muteBtn;
    private TextToSpeech tts;
    private boolean ttsReady = false, muted = false;

    private String current = "0";
    private String pending = null;
    private String operator = null;
    private boolean justEvaled = false;
    private String exprStr = "";

    private final int[][] themes = {
        {0xFFFF6FB8,0xFFD4006A},{0xFFFF4757,0xFFB30026},{0xFFFF7043,0xFFC63D00},
        {0xFFFFA726,0xFFC47000},{0xFFFFD700,0xFF9A8200},{0xFFA8E063,0xFF3D7A00},
        {0xFF26D0CE,0xFF007D7B},{0xFF5BC8F5,0xFF0066AA},{0xFF4B7BEC,0xFF1A3FAA},
        {0xFFA855F7,0xFF6200C9},{0xFFE040FB,0xFF9900CC},{0xFFFF6B9D,0xFFB3005E},
    };
    private final String[] themeNames = {
        "bubblegum","cherry","tangerine","sunshine","lemon","lime",
        "aqua","sky","blueberry","grape","orchid","flamingo"
    };

    private final String[] langCodes = {
        "en-US","en-GB","es-ES","fr-FR","de-DE","it-IT","pt-BR",
        "ja-JP","ko-KR","zh-CN","ar-SA","hi-IN","ru-RU","nl-NL","sv-SE","he-IL"
    };
    private final String[] langLabels = {
        "English (US)","English (UK)","Espanol","Francais","Deutsch","Italiano",
        "Portugues","Nihongo","Hangugeo","Zhongwen","Arabi","Hindi",
        "Russkiy","Nederlands","Svenska","Ivrit"
    };
    private int selectedLangIndex = 0;

    private final Map<String, Map<String,String>> phrases = new HashMap<>();
    private final String[] starEmojis = {"★","✦","✿","♥","◆"};
    private final android.os.Handler handler = new android.os.Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buildPhrases();
        tts = new TextToSpeech(this, this);

        rootLayout     = findViewById(R.id.rootLayout);
        displayText    = findViewById(R.id.display);
        expressionText = findViewById(R.id.expression);
        starsText      = findViewById(R.id.stars);
        muteBtn        = findViewById(R.id.muteBtn);

        Spinner spinner = findViewById(R.id.langSpinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item, langLabels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                selectedLangIndex = pos;
            }
            public void onNothingSelected(AdapterView<?> p) {}
        });

        muteBtn.setOnClickListener(v -> toggleMute());

        int[] digitIds = {R.id.btn0,R.id.btn1,R.id.btn2,R.id.btn3,
                          R.id.btn4,R.id.btn5,R.id.btn6,R.id.btn7,R.id.btn8,R.id.btn9};
        String[] digits = {"0","1","2","3","4","5","6","7","8","9"};
        for (int i = 0; i < digitIds.length; i++) {
            final String d = digits[i];
            Button b = findViewById(digitIds[i]);
            if (b != null) b.setOnClickListener(v -> { speak(d); onDigit(d); bounce(v); });
        }

        setClick(R.id.btnDot,     v -> { speak("dot");  onDot();     bounce(v); });
        setClick(R.id.btnBack,    v -> { speak("back"); onBack();    bounce(v); });
        setClick(R.id.btnClear,   v -> { speak("ac");   onClear();   bounce(v); });
        setClick(R.id.btnSign,    v -> { speak("sign"); onSign();    bounce(v); });
        setClick(R.id.btnPercent, v -> { speak("pct");  onPercent(); bounce(v); });
        setClick(R.id.btnDiv,     v -> { speak("div");  onOp("/");   bounce(v); });
        setClick(R.id.btnMul,     v -> { speak("mul");  onOp("*");   bounce(v); });
        setClick(R.id.btnSub,     v -> { speak("sub");  onOp("-");   bounce(v); });
        setClick(R.id.btnAdd,     v -> { speak("add");  onOp("+");   bounce(v); });
        setClick(R.id.btnEq,      v -> { onEquals();    bounce(v); });

        int[] themeIds = {R.id.theme1,R.id.theme2,R.id.theme3,R.id.theme4,
                          R.id.theme5,R.id.theme6,R.id.theme7,R.id.theme8,
                          R.id.theme9,R.id.theme10,R.id.theme11,R.id.theme12};
        for (int i = 0; i < themeIds.length; i++) {
            final int idx = i;
            View dot = findViewById(themeIds[i]);
            if (dot != null) dot.setOnClickListener(v -> { speakRaw(themeNames[idx]); applyTheme(idx); });
        }
        applyTheme(0);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setSpeechRate(1.05f);
            tts.setPitch(1.35f);
            ttsReady = true;
        }
    }

    private void toggleMute() {
        muted = !muted;
        muteBtn.setImageResource(muted ? android.R.drawable.ic_lock_silent_mode
                                       : android.R.drawable.ic_lock_silent_mode_off);
        if (!muted) speakRaw("unmuted!");
    }

    private void speakRaw(String text) {
        if (!ttsReady || muted) return;
        String code = langCodes[selectedLangIndex];
        String[] parts = code.split("-");
        Locale locale = parts.length > 1 ? new Locale(parts[0], parts[1]) : new Locale(parts[0]);
        tts.setLanguage(locale);
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
    }

    private void speak(String key) {
        Map<String,String> map = phrases.get(key);
        if (map == null) { speakRaw(key); return; }
        String code = langCodes[selectedLangIndex];
        String text = map.containsKey(code) ? map.get(code) : map.get("en-US");
        speakRaw(text != null ? text : key);
    }

    private void setClick(int id, View.OnClickListener l) {
        View v = findViewById(id);
        if (v != null) v.setOnClickListener(l);
    }

    private void applyTheme(int idx) {
        int bg = themes[idx][0];
        rootLayout.setBackgroundColor(bg);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        Button eq = findViewById(R.id.btnEq);
        if (eq != null) eq.setTextColor(themes[idx][1]);
    }

    private void bounce(View v) {
        AnimatorSet set = new AnimatorSet();
        ObjectAnimator sy = ObjectAnimator.ofFloat(v,"scaleY",1f,0.8f,1f);
        ObjectAnimator sx = ObjectAnimator.ofFloat(v,"scaleX",1f,0.8f,1f);
        sy.setInterpolator(new BounceInterpolator());
        sx.setInterpolator(new BounceInterpolator());
        set.playTogether(sy,sx); set.setDuration(300); set.start();
    }

    private void celebrate(String answer) {
        Random rnd = new Random();
        String star = starEmojis[rnd.nextInt(starEmojis.length)];
        starsText.setText(star+" "+star+" "+star);
        Map<String,String> wowMap = phrases.get("wow");
        String code = langCodes[selectedLangIndex];
        String cheer = (wowMap != null && wowMap.containsKey(code)) ? wowMap.get(code) : "Amazing! The answer is";
        speakRaw(cheer + " " + answer);
        handler.removeCallbacksAndMessages(null);
        handler.postDelayed(() -> starsText.setText(""), 2200);
    }

    private void onDigit(String d) {
        if (justEvaled) { current=d; exprStr=""; justEvaled=false; }
        else if (current.equals("0")) current=d;
        else if (current.replace("-","").length()<10) current+=d;
        updateDisplay();
    }

    private void onDot() {
        if (justEvaled) { current="0."; justEvaled=false; }
        else if (!current.contains(".")) current+=".";
        updateDisplay();
    }

    private void onBack() {
        if (justEvaled || current.equals("Oops!")) { current="0"; justEvaled=false; }
        else if (current.length()>1) current=current.substring(0,current.length()-1);
        else current="0";
        exprStr=""; expressionText.setText("");
        updateDisplay();
    }

    private void onClear() {
        current="0"; pending=null; operator=null;
        justEvaled=false; exprStr="";
        expressionText.setText(""); starsText.setText("");
        updateDisplay();
    }

    private void onSign() {
        if (!current.equals("0"))
            current = current.startsWith("-") ? current.substring(1) : "-"+current;
        updateDisplay();
    }

    private void onPercent() {
        current=fmt(Double.parseDouble(current)/100);
        justEvaled=true; updateDisplay();
    }

    private void onOp(String op) {
        if (operator!=null&&!justEvaled)
            current=fmt(calc(Double.parseDouble(pending),operator,Double.parseDouble(current)));
        pending=current; operator=op;
        exprStr=pending+" "+sym(op);
        expressionText.setText(exprStr);
        justEvaled=true; updateDisplay();
    }

    private void onEquals() {
        if (operator==null) { justEvaled=true; return; }
        double r=calc(Double.parseDouble(pending),operator,Double.parseDouble(current));
        exprStr=fmt(Double.parseDouble(pending))+" "+sym(operator)+" "+fmt(Double.parseDouble(current));
        current=fmt(r);
        expressionText.setText(exprStr+" =");
        operator=null; pending=null; justEvaled=true;
        celebrate(current); updateDisplay();
    }

    private double calc(double a,String op,double b){
        switch(op){case"+":return a+b;case"-":return a-b;case"*":return a*b;}
        return b==0?Double.NaN:a/b;
    }

    private String fmt(double n){
        if(!Double.isFinite(n)) return "Oops!";
        if(n==Math.floor(n)&&Math.abs(n)<1e9) return String.valueOf((long)n);
        return String.format("%.6f",n).replaceAll("0+$","").replaceAll("\\.$","");
    }

    private String sym(String op){
        switch(op){case"/":return"÷";case"*":return"×";case"-":return"−";}return"+";
    }

    private void updateDisplay(){
        String v=current;
        if(!v.equals("Oops!")&&v.length()>9){try{v=fmt(Double.parseDouble(v));}catch(Exception ignored){}}
        displayText.setText(v);
    }

    private void buildPhrases(){
        String[][] rows = {
            {"0","zero","zero","cero","zéro","null","zero","zero","ぜろ","영","零","صفر","शून्य","ноль","nul","noll","אפס"},
            {"1","one","one","uno","un","eins","uno","um","いち","일","一","واحد","एक","один","één","ett","אחד"},
            {"2","two","two","dos","deux","zwei","due","dois","に","이","二","اثنان","दो","два","twee","två","שתיים"},
            {"3","three","three","tres","trois","drei","tre","três","さん","삼","三","ثلاثة","तीन","три","drie","tre","שלוש"},
            {"4","four","four","cuatro","quatre","vier","quattro","quatro","し","사","四","أربعة","चार","четыре","vier","fyra","ארבע"},
            {"5","five","five","cinco","cinq","fünf","cinque","cinco","ご","오","五","خمسة","पाँच","пять","vijf","fem","חמש"},
            {"6","six","six","seis","six","sechs","sei","seis","ろく","육","六","ستة","छह","шесть","zes","sex","שש"},
            {"7","seven","seven","siete","sept","sieben","sette","sete","しち","칠","七","سبعة","सात","семь","zeven","sju","שבע"},
            {"8","eight","eight","ocho","huit","acht","otto","oito","はち","팔","八","ثمانية","आठ","восемь","acht","åtta","שמונה"},
            {"9","nine","nine","nueve","neuf","neun","nove","nove","く","구","九","تسعة","नौ","девять","negen","nio","תשע"},
            {"add","plus","plus","más","plus","plus","più","mais","たす","더하기","加","زائد","जमा","плюс","plus","plus","חיבור"},
            {"sub","minus","minus","menos","moins","minus","meno","menos","ひく","빼기","减","ناقص","घटाओ","минус","min","minus","חיסור"},
            {"mul","times","times","por","fois","mal","per","vezes","かける","곱하기","乘","ضرب","गुणा","умножить","keer","gånger","כפול"},
            {"div","divide","divide","dividir","divisé par","geteilt","diviso","dividir","わる","나누기","除","قسمة","भाग","делить","delen","delat","חילוק"},
            {"eq","equals","equals","igual","égal","gleich","uguale","igual","いくつ","같다","等于","يساوي","बराबर","равно","is","lika","שווה"},
            {"ac","clear","clear","borrar","effacer","löschen","cancella","limpar","クリア","지우기","清除","مسح","मिटाओ","очистить","wissen","rensa","מחק"},
            {"back","delete","delete","borrar","effacer","löschen","cancella","apagar","けす","지우기","删除","حذف","हटाओ","удалить","wissen","radera","מחק"},
            {"dot","point","point","punto","virgule","Komma","virgola","ponto","てん","점","点","نقطة","बिंदु","точка","punt","punkt","נקודה"},
            {"sign","flip","flip","cambiar","changer","wechseln","cambia","trocar","かえる","바꾸기","变号","تغيير","बदलो","сменить","omdraaien","ändra","הפוך"},
            {"pct","percent","percent","por ciento","pour cent","Prozent","percento","por cento","パーセント","퍼센트","百分比","بالمئة","प्रतिशत","процент","procent","procent","אחוז"},
            {"wow","Amazing! The answer is","Brilliant! The answer is","Increible! La respuesta es","Bravo! La reponse est","Super! Die Antwort ist","Fantastico! La risposta e","Incrivel! A resposta e","sugoi! kotae wa","jalhaesseoyo! dab-eun","Tai bang le! da'an shi","raye! aljawab hw","Shabash! uttar hai","Molodets! Otvet","Geweldig! Het antwoord is","Bra jobbat! Svaret ar","Madehim! Hateshuvah hi"},
        };
        for (String[] row : rows) {
            Map<String,String> map = new HashMap<>();
            for (int i = 1; i < row.length && i-1 < langCodes.length; i++) {
                map.put(langCodes[i-1], row[i]);
            }
            phrases.put(row[0], map);
        }
    }

    @Override
    protected void onDestroy(){
        if(tts!=null){tts.stop();tts.shutdown();}
        super.onDestroy();
    }
}
